import 'package:flutter/widgets.dart';

class SearchAdmin extends StatelessWidget {
  Widget build(BuildContext context) {
    return Container();
  }
}
