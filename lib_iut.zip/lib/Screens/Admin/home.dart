import 'package:flutter/material.dart';
import 'package:iut_companion/Screens/Admin/components/adminTabWork.dart';
import 'package:iut_companion/Screens/Tabs/dependencies/functions.dart';
import 'package:iut_companion/constants.dart';

class HomeAdmin extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
